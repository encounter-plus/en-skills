# Encounter TypeScript SDK

Предварительный SDK нового en.cx API. ESM, JavaScript и TypeScript declarations.
Содержит HTTP-клиент, генерируемые методы API и отдельный WebSocket-клиент.
Не требует Kotlin, Python, Go или файлов монорепозитория для использования.

```ts
import { EncounterClient, generated } from '@encounter-api/sdk';

const client = new EncounterClient({
  baseUrl: 'https://demo.en.cx/api',
  siteDomain: 'demo.en.cx',
  tokenProvider: () => token,
});
const games = client.api(generated.GamesApi);
const details = await games.getGamesByIdDetails({ id: gameId });
```

`token` и `gameId` предоставляет приложение. Хранение токена остаётся в приложении.
Среда должна предоставлять fetch и WebSocket либо их адаптеры.
Контракт предварительный: часть ответов API ещё не типизирована.

Для сборки из исходного монорепозитория: `npm ci`, затем `npm run build:typescript`
из корня (Node.js 22+, JDK 21). Готовый архив включает только этот SDK.
